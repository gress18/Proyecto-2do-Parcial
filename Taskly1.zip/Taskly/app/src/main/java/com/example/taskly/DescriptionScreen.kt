package com.example.taskly.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.taskly.R // Asegúrate de que R.drawable.proyectofinal exista

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DescriptionScreen(navController: NavController) {
    // Variable de estado para el campo de texto de descripción
    var descriptionText by remember { mutableStateOf("") }

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    // Solo necesitamos los colores para el texto y el fondo general, no para el TextField
    val textColor = Color.White
    val hintColor = Color.White.copy(alpha = 0.6f)


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(horizontal = 24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {

            // 1. Espacio superior para bajar el contenido
            Spacer(modifier = Modifier.height(60.dp))

            // 2. Logo (Usando Text como placeholder si 'proyectofinal' no existe)
            Text(
                text = "Taskly",
                fontWeight = FontWeight.Bold,
                fontSize = 40.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // 3. Título
            Text(
                text = "Muestra tu verdadero Yo!",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            )

            // 4. Descripción
            Text(
                text = "Describe tus actividades, a qué te dedicas, logros, qué te gusta hacer, el último puesto que tuviste, en dónde trabajaste.",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 15.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 24.dp)
            )

            // 5. CAMPO DE TEXTO MULTILINEA (SIN ARGUMENTO 'COLORS')
            OutlinedTextField(
                value = descriptionText,
                onValueChange = { descriptionText = it },
                label = { Text("Escribe aquí...", color = hintColor) },
                // Esto hace que el campo sea alto y el texto se alinee arriba
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                shape = RoundedCornerShape(12.dp),
                // ❌ SOLUCIÓN: El argumento 'colors' se ELIMINA para evitar el error de referencia.
            )

            // Espacio antes del botón
            Spacer(modifier = Modifier.height(32.dp))

            // 6. BOTÓN SIGUIENTE
            Button(
                onClick = {
                    navController.navigate("profile_picture") // CAMBIO CLAVE
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(
                    "Siguiente",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            // Espacio al fondo para rellenar
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}