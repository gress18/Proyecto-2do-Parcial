package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.draw.clip

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkScreen(navController: NavController) {

    // Simulación de datos
    val activeTasks = listOf(
        "Instalar tubería en baño",
        "Pasear perro - 2 horas",
        "Limpieza profunda de oficina"
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Mis Trabajos",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF0F0F0)
    ) { paddingValues ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
        ) {

            // --- Título de Tareas Activas ---
            item {
                Text(
                    "Tareas Activas (${activeTasks.size})",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // ✅ CORRECCIÓN: La llamada es correcta si TaskCard está definida abajo
            // --- Lista de Tareas Activas ---
            items(activeTasks) { task ->
                TaskCard(task)
            }

            // --- Separador y Trabajos Completados ---
            item {
                Spacer(Modifier.height(24.dp))
                Divider(color = Color.Gray.copy(alpha = 0.3f), thickness = 1.dp)
                Spacer(Modifier.height(16.dp))
                Text(
                    "Historial (Completados)",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // Placeholder para trabajos completados
            item {
                Text(
                    "No hay trabajos completados recientemente.",
                    color = Color.Gray,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    }
}

// ✅ Función auxiliar dentro del mismo archivo
@Composable
fun TaskCard(task: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icono de Trabajo
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF116DCA)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Work, contentDescription = null, tint = Color.White)
            }
            Spacer(Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(task, fontWeight = FontWeight.Medium, color = Color.Black)
                Text("Progreso: 70%", fontSize = 12.sp, color = Color.Gray)
            }

            Icon(Icons.Default.ArrowForwardIos, contentDescription = "Detalle", tint = Color.Black.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
        }
    }
}