package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast // Para la funcionalidad de Toast

// Importa Image si tienes un drawable de placeholder para la foto de perfil
// import androidx.compose.foundation.Image
// import androidx.compose.ui.res.painterResource
// import com.example.taskly.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilePictureScreen(navController: NavController) {

    val context = LocalContext.current // Para usar Toast

    // Simular el estado de la imagen (podría ser un Uri real)
    // var profileImageUri by remember { mutableStateOf<Uri?>(null) }

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    Scaffold(
        // 1. BARRA DE HERRAMIENTAS (Toolbar)
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("") }, // Sin título
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) { // Simula 'finish()'
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent, // Fondo transparente
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Color.Transparent, // Hace que el fondo del Scaffold sea transparente para que se vea el Box
        modifier = Modifier.background(gradient)
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues) // Aplica el padding de la TopBar
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // 2. LOGO (Reemplazamos la imagen por un placeholder o Text)
                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = "Taskly",
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 60.dp)
                )

                // 3. CÍRCULO DE LA FOTO DE PERFIL (ivProfilePic)
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.5f)) // Fondo gris/semitransparente
                        .clickable {
                            // 6. Lógica para seleccionar la imagen
                            Toast.makeText(context, "Abrir galería para seleccionar foto", Toast.LENGTH_SHORT).show()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Añadir Foto",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 16.sp
                    )
                    // Si tuvieras un drawable de placeholder:
                    /*
                    Image(
                        painter = painterResource(id = R.drawable.placeholder_user),
                        contentDescription = "Foto de perfil",
                        modifier = Modifier.fillMaxSize()
                    )
                    */
                }

                // 4. TÍTULO/INSTRUCCIÓN
                Text(
                    text = "Añade una Foto de Perfil",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = Color.White,
                    modifier = Modifier.padding(top = 32.dp, bottom = 16.dp)
                )

                // 5. DESCRIPCIÓN
                Text(
                    text = "Una buena foto aumenta tus oportunidades. Asegúrate de que tu rostro sea visible.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(0.8f)
                )
            }

            // 6. BOTÓN SIGUIENTE (btnSiguiente)
            Button(
                onClick = {
                    // Navegando a la siguiente pantalla (ej. 'premium')
                    Toast.makeText(context, "Navegando a Premium...", Toast.LENGTH_SHORT).show()
                    navController.navigate("premium")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(bottom = 24.dp) // Margen inferior
            ) {
                Text(
                    "Siguiente",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}