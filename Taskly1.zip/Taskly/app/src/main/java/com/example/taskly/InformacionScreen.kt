package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
// ❌ IMPORTACIÓN ELIMINADA: import androidx.compose.material3.TextFieldDefaults

// La anotación ExperimentalMaterial3Api ya no es estrictamente necesaria,
// pero la dejamos por si acaso.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InformacionScreen(navController: NavController) {
    var telefono by remember { mutableStateOf("") }
    var codigoPostal by remember { mutableStateOf("") }
    var ubicacion by remember { mutableStateOf("") }
    var puedoReubicarme by remember { mutableStateOf(false) }

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    // Las variables de color ya no son necesarias, pero se dejan las básicas
    val focusedLabelColor = Color.White.copy(alpha = 0.8f)
    val unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
    val textColor = Color.White

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(horizontal = 24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            // Espacio Inicial para bajar el contenido
            Spacer(modifier = Modifier.height(120.dp))

            Text(
                text = "INFORMACIÓN PERSONAL",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.White
            )

            Text(
                text = "Tus datos están seguros y solo la persona que proporcione el empleo podrá verlo",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // -------------------- CAMPOS DE TEXTO (SIN PERSONALIZACIÓN DE COLOR) --------------------
            OutlinedTextField(
                value = telefono,
                onValueChange = { telefono = it },
                label = { Text("¿Cuál es tu número telefónico?") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                // 🚀 SOLUCIÓN: Se omite el argumento 'colors' por completo.
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = codigoPostal,
                onValueChange = { codigoPostal = it },
                label = { Text("¿Cuál es tu Código Postal?") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                // 🚀 SOLUCIÓN: Se omite el argumento 'colors' por completo.
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = ubicacion,
                onValueChange = { ubicacion = it },
                label = { Text("¿Cuál es tu ubicación?") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                // 🚀 SOLUCIÓN: Se omite el argumento 'colors' por completo.
            )
            // -----------------------------------------------------------------------------------------

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Switch(
                    checked = puedoReubicarme,
                    onCheckedChange = { puedoReubicarme = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF8E24AA)
                    )
                )
                Text(
                    text = "¿Puedo reubicarme?",
                    color = Color.White,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            // AJUSTE: Subir el botón
            Spacer(modifier = Modifier.height(50.dp))

            Button(
                onClick = { navController.navigate("educacion") },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(40.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) {
                Text("Siguiente", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}