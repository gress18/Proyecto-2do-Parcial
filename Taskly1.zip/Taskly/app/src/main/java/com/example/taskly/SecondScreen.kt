package com.example.taskly

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun SecondScreen(navController: NavController) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
                    )
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Top
            ) {
                // Spacer para subir el contenido (casi al borde)
                Spacer(modifier = Modifier.height(10.dp))

                // Contenedor para el logo y el texto
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Logo Taskly
                    Image(
                        painter = painterResource(id = R.drawable.logo2), // Usando logo2
                        contentDescription = "Logo Taskly",
                        modifier = Modifier
                            .size(300.dp) // Tamaño grande
                            .padding(bottom = 0.dp)
                            .align(Alignment.CenterHorizontally)
                    )

                    // Texto principal (desplazado hacia arriba)
                    Text(
                        text = "MILES DE\nTRABAJOS AL\nALCANCE DE TU\nMANO",
                        fontSize = 38.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        lineHeight = 42.sp,
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset(y = (-40).dp) // Desplazamiento hacia arriba
                            .align(Alignment.Start)
                    )
                }

                Spacer(modifier = Modifier.height(30.dp)) // Espacio entre el texto superior y el cuadro blanco

                // Recuadro blanco inferior
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(
                            Color.White,
                            shape = RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp)
                        )
                        .padding(vertical = 48.dp, horizontal = 20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Text(
                            text = "Planea tu día",
                            fontSize = 22.sp,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        Text(
                            text = "Imagina: en una mañana puedes cuidar niños, al mediodía repartir volantes y por la tarde dar una clase particular. Taskly encadena estos micro-empleos y convierte tu tiempo libre en ingresos organizados.",
                            fontSize = 15.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(bottom = 40.dp)
                        )

                        Button(
                            onClick = { navController.navigate("login") },
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text(
                                text = "Siguiente",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(Color(0xFF116DCA), shape = RoundedCornerShape(50))
                        )
                    }
                }
            }
        }
    }
}