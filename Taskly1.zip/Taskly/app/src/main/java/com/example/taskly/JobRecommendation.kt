package com.example.taskly

data class JobRecommendation(
    val name: String,
    val jobTitle: String,
    val location: String,
    val price: String,
    val imageRes: Int
)
