package com.example.taskly.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavController as NavHostController // Usamos NavController de navigation-compose

// Importaciones de tus pantallas
import com.example.taskly.screens.LoginScreen
import com.example.taskly.SecondScreen
import com.example.taskly.RegisterScreen
import com.example.taskly.screens.CVScreen
import com.example.taskly.screens.DescriptionScreen
import com.example.taskly.screens.DocumentsScreen
import com.example.taskly.screens.ProfilePictureScreen
import com.example.taskly.screens.EducationScreen
import com.example.taskly.screens.HomeScreen
import com.example.taskly.screens.PremiumScreen
import com.example.taskly.screens.InformacionScreen
import com.example.taskly.screens.Pantalla1
import com.example.taskly.screens.ProfileScreen
import com.example.taskly.screens.WorkScreen

// Define las rutas que deben mostrar la barra inferior
private val BOTTOM_NAV_SCREENS = listOf("home", "documents", "work", "profile")

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    // Observa el BackStack para saber la ruta actual
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    // --- 1. Scaffold Principal (Contiene la Bottom Bar) ---
    Scaffold(
        bottomBar = {
            // Solo muestra la barra si la ruta actual está en la lista permitida
            if (currentRoute in BOTTOM_NAV_SCREENS) {
                NavigationBar(containerColor = Color.White) {

                    // Definición de ítems de la barra
                    val items = listOf(
                        Triple("Home", Icons.Default.Home, "home"),
                        Triple("Documentos", Icons.Default.Folder, "documents"),
                        Triple("Trabajo", Icons.Default.Work, "work"),
                        Triple("Perfil", Icons.Default.Person, "profile")
                    )

                    items.forEach { (label, icon, route) ->
                        NavigationBarItem(
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            // El ítem se selecciona si su ruta coincide con la ruta actual
                            selected = currentRoute == route,
                            onClick = {
                                // Navegación optimizada para Bottom Bar
                                navController.navigate(route) {
                                    // Limpia la pila para que no quede la Home varias veces
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true // Evita duplicados en la pila
                                    restoreState = true // Mantiene el estado de la pantalla al volver
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->

        // --- 2. NavHost (Donde se cargan las pantallas) ---
        NavHost(
            navController = navController,
            startDestination = "pantalla1",
            // MUY IMPORTANTE: Aplica el padding del Scaffold aquí
            modifier = Modifier.padding(paddingValues)
        ) {

            // Rutas de inicio y autenticación
            composable("pantalla1") { Pantalla1(navController) }
            composable("second") { SecondScreen(navController) }
            composable("login") { LoginScreen(navController) }
            composable("register") { RegisterScreen(navController) }

            // Rutas de creación de CV
            composable("cv") { CVScreen(navController) }
            composable("informacion") { InformacionScreen(navController) }
            composable("educacion") { EducationScreen(navController) }
            composable("description") { DescriptionScreen(navController) }
            composable("profile_picture") { ProfilePictureScreen(navController) }
            composable("premium") { PremiumScreen(navController) }

            // Rutas de la Barra Inferior (Solo contenido de la pantalla)
            composable("home") { HomeScreen(navController) }
            composable("documents") { DocumentsScreen(navController) }
            composable("work") { WorkScreen(navController) }
            composable("profile") { ProfileScreen(navController) }

            // Rutas adicionales que no usan Bottom Bar
            // composable("notifications") { NotificationsScreen(navController) } // (Si la creaste)
        }
    }
}