package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.taskly.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationScreen(navController: NavController) {
    var grado by remember { mutableStateOf("") }

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(horizontal = 24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {

            // 1. Espacio para bajar el contenido
            Spacer(modifier = Modifier.height(120.dp))

            Text(
                text = "EDUCACIÓN",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.White
            )

            Text(
                text = "Cuéntanos sobre tu formación académica",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Espacio entre subtítulo y campo de texto
            Spacer(modifier = Modifier.height(32.dp))

            // Campo de texto
            OutlinedTextField(
                value = grado,
                onValueChange = { grado = it },
                label = { Text("¿Cuál es tu último grado de estudios?") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // 2. Espacio pequeño y fijo para colocar el botón
            Spacer(modifier = Modifier.height(32.dp))

            Button(
                // 🚀 CAMBIO CLAVE: Navega a la pantalla "description"
                onClick = { navController.navigate("description") },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(40.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) {
                Text("Finalizar", color = Color.White, fontWeight = FontWeight.Bold)
            }

            // 3. Usamos weight(1f) aquí para empujar el *resto* del espacio sobrante al fondo.
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}
