package com.example.taskly.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.taskly.R

@Composable
fun Pantalla1(navController: NavController) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 30.dp, vertical = 30.dp)
        ) {
            // 1. Espaciador para bajar el contenido y evitar la muesca/cámara frontal
            Spacer(modifier = Modifier.height(60.dp))

            // 2. Logo Taskly - Centrado y más grande
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.taskly1),
                    contentDescription = "Logo Taskly",
                    modifier = Modifier.height(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(50.dp))

            // 3. Imagen central (Avión)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img1),
                    contentDescription = "Ilustración de avión y persona",
                    modifier = Modifier.fillMaxWidth(0.9f)
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            // 4. Título
            Text(
                text = buildAnnotatedString {
                    append("Encuentra los\n")
                    withStyle(style = SpanStyle(color = Color(0xFFFF9540))) {
                        append("Mejores trabajos")
                    }
                    append("\nEn Taskly!")
                },
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                lineHeight = 38.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Subtítulo
            Text(
                text = "Explora todos los roles de trabajos basados en tus intereses",
                fontSize = 16.sp,
                color = Color.Gray,
                modifier = Modifier.fillMaxWidth(0.8f)
            )

            // 6. Espaciador para empujar el botón al final
            Spacer(modifier = Modifier.weight(1f))

            // 7. Botón de Navegación
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .clickable { navController.navigate("second") }
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = "Siguiente",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}