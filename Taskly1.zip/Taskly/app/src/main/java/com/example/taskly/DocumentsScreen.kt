package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentsScreen(navController: NavController) {

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    Scaffold(
        // ✅ CORRECCIÓN: Estructura correcta del topBar
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Mis Documentos",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White
                ),
                modifier = Modifier.background(gradient) // Aplica el degradado al TopAppBar
            )
        },
        containerColor = Color.Transparent,
        modifier = Modifier.background(gradient)
    ) { paddingValues ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
        ) {

            // --- Tarjeta de CV Principal ---
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            "Currículum Vitae (CV)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Tu documento principal para aplicar a empleos en Taskly. Actualízalo para mejores resultados.",
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { navController.navigate("cv") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Editar CV", color = Color.White)
                        }
                    }
                }
            }

            // --- Sección de Documentos Adicionales ---
            item {
                Text(
                    "Certificados y Licencias",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            item {
                DocumentItem(
                    title = "Licencia de Conducir",
                    subtitle = "Válida hasta 2028",
                    icon = Icons.Default.DirectionsCar,
                    onClick = { /* Lógica para ver el documento */ }
                )
            }
            item {
                DocumentItem(
                    title = "Certificado de Plomería",
                    subtitle = "Emitido por SENA",
                    icon = Icons.Default.Construction,
                    onClick = { /* Lógica para ver el documento */ }
                )
            }

            // --- Botón para subir nuevo documento ---
            item {
                Spacer(Modifier.height(24.dp))
                OutlinedButton(
                    onClick = { /* Lógica para abrir selector de archivos */ },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(Color.White, Color.White.copy(alpha = 0.5f))))
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Subir Nuevo Documento")
                }
            }
        }
    }
}

// ✅ Función auxiliar dentro del mismo archivo
@Composable
fun DocumentItem(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
            .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Ver",
            tint = Color.White
        )
    }
}