package com.example.taskly.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.taskly.JobRecommendation
import com.example.taskly.R


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {

    val context = LocalContext.current
    var searchText by remember { mutableStateOf("") }
    var locationText by remember { mutableStateOf("") }

    // 1. ESTADO DE LA LISTA ORIGINAL Y LA LISTA FILTRADA
    val originalJobList = remember {
        listOf(
            JobRecommendation("Saul Hernandez", "Chofer x 2 horas", "Pachuca de Soto", "$400", R.drawable.ic_launcher_foreground),
            JobRecommendation("Maria Lopez", "Servicio de limpieza", "Mineral de la Reforma", "$500", R.drawable.ic_launcher_foreground),
            JobRecommendation("Carlos Mendoza", "Plomero urgente", "Centro", "$350", R.drawable.ic_launcher_foreground)
        )
    }
    // Lista mutable que se mostrará en el LazyColumn (inicialmente es la lista completa)
    var filteredJobList by remember { mutableStateOf(originalJobList) }


    Column(modifier = Modifier.fillMaxSize()) {

        // ========================= TOP BAR (Header) =========================
        Column(
            modifier = Modifier
                .background(Color(0xFF45C0F5))
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    text = "Taskly",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = {
                    navController.navigate("notifications")
                }) {
                    Icon(Icons.Default.Notifications, contentDescription = "Notificaciones", tint = Color.White)
                }
            }

            // ========================= CAMPOS DE TEXTO =========================

            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("Trabajo") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Black,
                        unfocusedIndicatorColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                OutlinedTextField(
                    value = locationText,
                    onValueChange = { locationText = it },
                    label = { Text("Ubicación") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Black,
                        unfocusedIndicatorColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
            }

            // ========================= BOTÓN BUSCAR (LÓGICA IMPLEMENTADA) =========================

            Button(
                onClick = {
                    // 3. Lógica de Filtrado
                    val filtered = originalJobList.filter { job ->
                        val textMatch = if (searchText.isBlank()) true else job.jobTitle.contains(searchText, ignoreCase = true)
                        val locationMatch = if (locationText.isBlank()) true else job.location.contains(locationText, ignoreCase = true)
                        textMatch && locationMatch
                    }

                    // Actualiza la lista que se muestra en la UI
                    filteredJobList = filtered

                    // Muestra un Toast con el resultado
                    Toast.makeText(
                        context,
                        "Resultados encontrados: ${filtered.size}",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Buscar", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        // ========================= LISTA DE TRABAJOS =========================

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {

            item {
                Text(
                    "Trabajos Recomendados",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // 2. Muestra la lista FILTRADA
            items(filteredJobList) { job ->
                RecommendationCard(job)
            }
        }
    }
}

// ... (La función RecommendationCard se deja aquí para que el archivo sea autocontenido)
@Composable
fun RecommendationCard(job: JobRecommendation) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F0F0))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            // Placeholder redondo
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Color.Gray),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = "User Icon", tint = Color.White)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {

                Text(job.jobTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                Text(job.name, fontSize = 14.sp, color = Color.Gray)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location", modifier = Modifier.size(16.dp), tint = Color.Gray)
                    Text(job.location, fontSize = 12.sp, color = Color.Gray)
                }
            }

            Text(job.price, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.Black)
        }
    }
}