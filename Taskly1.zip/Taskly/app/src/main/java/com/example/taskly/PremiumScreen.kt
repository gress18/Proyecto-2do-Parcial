package com.example.taskly.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast // Para la funcionalidad de Toast
import androidx.compose.foundation.clickable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumScreen(navController: NavController) {

    val context = LocalContext.current
    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF45C0F5), Color(0xFF116DCA))
    )

    // Simulación del botón "Hazte Premium"
    val onPremiumClick: () -> Unit = {
        Toast.makeText(context, "¡Bienvenido a Premium! (Navegar a Home)", Toast.LENGTH_SHORT).show()
        // En Compose, para simular CLEAR_TASK, simplemente navegamos a Home sin posibilidad de volver
        // En Compose, para simular CLEAR_TASK, simplemente navegamos a Home sin posibilidad de volver
        navController.navigate("home") {
            // Esto elimina todas las pantallas anteriores de la pila.
            popUpTo(navController.graph.id) { inclusive = true }
        }
    }

    // Simulación del botón "En otro momento"
    val onSkipClick: () -> Unit = {
        Toast.makeText(context, "Saltando al Home...", Toast.LENGTH_SHORT).show()
        navController.navigate("home") {
            popUpTo(navController.graph.id) { inclusive = true }
        }
    }

    Scaffold(
        // 1. BARRA DE HERRAMIENTAS (Toolbar)
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("") }, // Sin título
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) { // Simula el botón de retroceso
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = Modifier.background(gradient)
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            // Usamos SpaceBetween y Weight para posicionar el contenido y los botones
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f) // Esto empuja los botones hacia abajo
            ) {
                // Icono/Imagen Premium (Simulado con un ícono grande)
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = "Premium Star",
                    tint = Color(0xFFFFD700), // Dorado
                    modifier = Modifier.size(100.dp).padding(top = 32.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // TÍTULO
                Text(
                    text = "¡Desbloquea Taskly Premium!",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp,
                    color = Color.White,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // DESCRIPCIÓN/BENEFICIOS
                Text(
                    text = "Obtén acceso ilimitado a ofertas exclusivas, asistencia prioritaria y herramientas avanzadas para conseguir el mejor trabajo.",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 16.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(0.9f)
                )
            }

            // --- Sección de Botones ---
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp)
            ) {

                // BOTÓN 1: Hazte Premium
                Button(
                    onClick = onPremiumClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        "Hazte Premium",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // BOTÓN 2: En otro momento (Texto clickeable)
                Text(
                    text = "En otro momento",
                    color = Color.White.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .clickable(onClick = onSkipClick)
                        .padding(8.dp)
                )
            }
        }
    }
}
